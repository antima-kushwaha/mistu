
const fallingColor = document.getElementById("falling-color");
const buttons = document.querySelectorAll(".color-btn");
const scoreDisplay = document.getElementById("score");
const colors = ["red", "green", "blue"];
let currentColor = "";
let score = 0;


let highScore = localStorage.getItem("highScore") || 0;
const highScoreDisplay = document.createElement("p");
highScoreDisplay.textContent = `High Score: ${highScore}`;
document.getElementById("game-area").appendChild(highScoreDisplay);


let time = 30;
const timerDisplay = document.getElementById("timer");

function startTimer() {
  let timer = setInterval(() => {
    time--;
    timerDisplay.textContent = `⏰ Time: ${time}`;
    if (time <= 0) {
      clearInterval(timer);
      gameOver();
    }
  }, 1000);
}


function getRandomColor() {
  return colors[Math.floor(Math.random() * colors.length)];
}

function dropColor() {
  currentColor = getRandomColor();
  fallingColor.style.backgroundColor = currentColor;
  fallingColor.style.top = "0px";

  let drop = setInterval(() => {
    let top = parseInt(fallingColor.style.top);
    if (top >= 350) {
      clearInterval(drop);
      gameOver();
    } else {
      fallingColor.style.top = `${top + 5}px`;
    }
  }, 50);

  if (score === 0) startTimer();
}


buttons.forEach((btn) => {
  btn.addEventListener("click", () => {
    if (btn.dataset.color === currentColor) {
      score++;
      scoreDisplay.textContent = `Score: ${score}`;
      dropColor();
    } else {
      gameOver();
    }
  });
});


function gameOver() {
  alert(`Game Over! Your score: ${score}`);

  if (score > highScore) {
    highScore = score;
    localStorage.setItem("highScore", highScore);
  }

  highScoreDisplay.textContent = `High Score: ${highScore}`;

  score = 0;
  scoreDisplay.textContent = "Score: 0";
  time = 30;
  timerDisplay.textContent = `⏰ Time: ${time}`;

  dropColor();
}


dropColor();
